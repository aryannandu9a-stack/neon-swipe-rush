# Neon Swipe Rush — Website + Android starter project

## What's included
- `www/index.html`: playable responsive game with lane switching, levels, Web Audio sound effects, persistent best score/coins, cosmetic skins, daily missions, pause/restart.
- `www/manifest.webmanifest`, `www/sw.js`, `www/icon.svg`: installable/offline-friendly PWA assets.
- `package.json`: optional Capacitor setup for a native Android wrapper.
- `MONETIZATION.md`: honest integration plan for ads and purchases.

## Test the game on your Android phone
1. Download and extract this ZIP.
2. Open `www/index.html` in a browser or use a local static server. Some browsers restrict service workers when opening a `file://` URL; the game itself should still run.
3. For the easiest public test, upload the contents of the `www` folder to a GitHub repository and enable GitHub Pages (Settings → Pages → deploy from branch → `main` → `/www` or use root if you move the files to the root).
4. Open the published HTTPS URL on your Android phone. In Chrome, menu `⋮` → **Add to Home screen** (wording varies).

## Native Android route (Capacitor)
This route usually needs Node.js and Android Studio to build an APK. A phone-only browser cannot reliably compile a native Android project locally. Use a computer, or a trusted cloud development/build environment if available.
1. Install Node.js LTS and Android Studio on a computer.
2. Extract the project, open a terminal in this folder, and run:
   `npm install`
   `npm run android:add`
   `npm run android:sync`
   `npm run android:open`
3. In Android Studio, wait for Gradle sync, choose a test device/emulator, then Run.
4. To make a debug APK: Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s). Test on your own device before distribution.

## Important
- Ads and real-money purchases are NOT implemented in this prototype. The bonus button is a clearly labelled demo placeholder.
- Never use live ad clicks to test your own ads. Use official test ad unit IDs until release.
- For AdMob in a native app, follow the current official Google Mobile Ads SDK and AdMob policy documentation. A web page inside a wrapper needs a compatible, policy-compliant implementation; do not paste native SDK code directly into HTML.
- For in-app digital goods on Google Play, use Google Play Billing where required by current policy. Do not collect card details yourself.
- Before publishing, add a privacy policy, disclose relevant data collection, use appropriate age/content settings, test purchases, and comply with Google Play, AdMob and local requirements.
- LocalStorage-based coins/skins are local to the device and can be reset; they are not secure against cheating. A production leaderboard or purchases require server-side validation.
