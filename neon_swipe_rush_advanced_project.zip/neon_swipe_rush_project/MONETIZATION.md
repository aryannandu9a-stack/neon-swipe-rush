# Monetization integration plan

This starter is playable but does not contain a live ad SDK or real-money checkout.

## Ads
1. Decide whether the first release is a website/PWA or native Android. They use different integration paths.
2. Create an AdMob account and register the actual app after reviewing eligibility and current policies.
3. For native Android, follow Google's current Mobile Ads SDK integration guide and use test ad unit IDs during development.
4. Add rewarded ads only after a player voluntarily chooses a reward. Show clear reward terms and grant the reward only after the SDK reports successful completion.
5. Consider an unobtrusive interstitial only at a natural break; avoid accidental clicks or ads covering controls.
6. Do not click live ads yourself. Never promise revenue.

## Purchases
- Current skin purchases spend earned in-game coins only.
- For paid digital skins or a remove-ads option in a Google Play app, integrate Google Play Billing where required and verify purchases securely.
- Do not treat a client-side JavaScript flag as proof of payment. Validate transactions and entitlements on a backend.
- Website purchases need a suitable payment provider and its own terms, privacy and refund handling.

## Before release
- Privacy policy and accurate data-safety disclosures.
- Consent and age-appropriate setup where required.
- Test ads, test purchases, restore-purchase flow and failure states.
- Store listing assets, support contact, crash testing, performance checks.
