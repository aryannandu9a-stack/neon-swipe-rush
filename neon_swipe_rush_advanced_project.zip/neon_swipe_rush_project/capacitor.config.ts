import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.neonswiperush.game',
  appName: 'Neon Swipe Rush',
  webDir: 'www',
  bundledWebRuntime: false
};
export default config;
